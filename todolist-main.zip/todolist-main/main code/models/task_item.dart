class TaskItem {
  String label;
  bool done;

  TaskItem({required this.label, this.done = false});
}
